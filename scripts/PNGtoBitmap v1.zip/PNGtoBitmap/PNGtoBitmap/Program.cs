﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;

namespace PNGtoBitmap
{
    class Program
    {
        class Tile
        {
            public int Index { get; }
            public string[] Bitmap = new string[16];
            public List<Color> Colors = new List<Color>();

            public Tile(int index)
            {
                Index = index;
            }
        }

        static void Main(string[] args)
        {
            // Generate ROM files and palette
            List<Color> palette = new List<Color>();
            palette = GenerateROM("tile_rom", palette);
            Console.WriteLine();
            palette = GenerateROM("entity_rom", palette);
            Console.WriteLine();

            // Print the palette to the palette file, if there is the correct number of colors
            Console.WriteLine("<--- CHECKING PALETTE --->");
            if (palette.Count <= 32)
            {
                // Set palette address and data widths
                int addrWidth = 31;
                int dataWidth = 31;

                // Prepare the output file
                if (File.Exists("outputs/palette_rom.sv"))
                    File.Delete("outputs/palette_rom.sv");
                File.AppendAllText("outputs/palette_rom.sv", $"module palette_rom (" +
                                                         $"\n    input logic [{addrWidth}:0] addr," +
                                                         $"\n    output logic [{dataWidth}:0] data" +
                                                         $"\n);\n" +
                                                         $"\n    parameter [0:2**{addrWidth}][{dataWidth}:0] ROM = " + "{");
                foreach (var color in palette)
                    File.AppendAllText("outputs/palette_rom.sv", $"\n        32'b{Convert.ToString(color.ToArgb(), 2).PadLeft(32, '0')},");
                File.AppendAllText($"outputs/palette_rom.sv", "\n    };\n\n    assign data = ROM[addr];\n\nendmodule");

                Console.WriteLine($"PASS: Printed {palette.Count}-color palette to outputs/palette_rom.sv");
            }
            else
                Console.WriteLine($"FAIL: Expected 32-color palette at most, found {palette.Count} colors.");

            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }

        static List<Color> GenerateROM(string rom, List<Color> palette)
        {
            Console.WriteLine($"<--- GENERATING {rom.ToUpper()} --->");
            try
            {
                // Attempt to retrieve the image
                var image = new Bitmap($"inputs/{rom}.png", true);

                // Initialize list to track the tiles and their corresponding colors
                List<Tile> Tiles = new List<Tile>();

                // Get the maximum bits for pixel from the colors per tile
                int colorsPerTile = (rom == "tile_rom") ? 4 : 8;
                int bitsPerPixel = (int)Math.Ceiling(Math.Log2(colorsPerTile));

                // Loop through the image pixels to get colors and bitmaps per tile
                string bitmap = "";
                for (int y = 0; y < image.Height; y++)
                {
                    for (int x = 0; x < image.Width; x++)
                    {
                        // Convert x,y coordinates into tile coordinates
                        int tileX = x / 16;
                        int tileY = y / 16;
                        int tileIndex = (image.Width / 16) * tileY + tileX;

                        // Get the current tile from our list or add it if it isnt there already
                        Tile currTile = new Tile(tileIndex);
                        if (Tiles.Count > tileIndex)
                            currTile = Tiles[tileIndex];
                        else
                            Tiles.Add(currTile);

                        // Get the color of the current pixel and add it to our tile's list if it isnt there already
                        Color pixelColor = image.GetPixel(x, y);
                        if (!currTile.Colors.Contains(pixelColor))
                            currTile.Colors.Add(pixelColor);

                        int bit = x % 16;
                        if (bit == 0) //reset the bitmap row on every 16th bit
                            bitmap = $"{bitsPerPixel * 16}'b";
                        else if (bit == 15) //save the current bitmap row before it gets reset
                            Tiles[tileIndex].Bitmap[y % 16] = bitmap;

                        // Convert color index to binary and pad with 0s if its less than the correct number of bits
                        bitmap += Convert.ToString(currTile.Colors.IndexOf(pixelColor), 2).PadLeft(bitsPerPixel, '0');

                        // Update the current tile
                        Tiles[tileIndex] = currTile;
                    }
                }

                if (Tiles.Count > 0)
                {
                    // Check for invalid tiles
                    var invalidTiles = Tiles.Where(t => t.Colors.Count > colorsPerTile);
                    Console.WriteLine($"Total Tile Count: {Tiles.Count}\nMax Colors Per Tile: {colorsPerTile}\n");
                    if (invalidTiles.Count() > 0)
                        Console.WriteLine($"FAIL: Found {invalidTiles.Count()} tiles with more than {colorsPerTile} colors: " +
                            $"{string.Join(", ", invalidTiles.Select(t => t.Index))}");
                    else
                    {
                        // If no invalid tiles are found, pass a success
                        Console.WriteLine($"PASS: All tiles have {colorsPerTile} colors or less.");

                        // Calculate ROM address and data widths
                        int addrWidth = (int)Math.Ceiling(Math.Log2(Tiles.Count)) - 1;
                        int dataWidth = bitsPerPixel * 16 - 1;

                        // Prepare the output file
                        if (File.Exists($"outputs/{rom}.sv"))
                            File.Delete($"outputs/{rom}.sv");
                        File.AppendAllText($"outputs/{rom}.sv", $"module {rom} (" +
                                                                $"\n    input logic [{addrWidth}:0] addr," +
                                                                $"\n    output logic [{dataWidth}:0] data" +
                                                                $"\n);\n" +
                                                                $"\n    parameter [0:2**{addrWidth}][{dataWidth}:0] ROM = " + "{");

                        // Print all bitmaps (with their corresponding indices) to output file
                        for (int i = 0; i < Tiles.Count; i++)
                        {
                            List<string> indices = new List<string>();
                            foreach (var color in Tiles[i].Colors)
                            {
                                if (!palette.Contains(color))
                                    palette.Add(color);
                                indices.Add(Convert.ToString(palette.IndexOf(color), 2).PadLeft(5, '0'));
                            }
                            File.AppendAllText($"outputs/{rom}.sv", $"\n        //code {i}: {string.Join(", ", indices)}" +
                                                              $"\n        {string.Join(",\n        ", Tiles[i].Bitmap)}");
                        }
                        File.AppendAllText($"outputs/{rom}.sv", "\n    };\n\n    assign data = ROM[addr];\n\nendmodule");
                        Console.WriteLine($"PASS: Printed all tiles to outputs/{rom}.sv");
                    }
                }
                else
                    Console.WriteLine($"No 16x16 tiles found in inputs/{rom}.png.");
            }
            catch (ArgumentException) { Console.WriteLine($"Unable to find inputs/{rom}.png."); }

            return palette;
        }
    }
}
